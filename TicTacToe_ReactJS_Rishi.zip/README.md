The code is in Game.tsx
The corressponding css is in Game.css.
App.tsx and App.css are redundant for now